select * from Table_AttendanceData a
	left join Table_UserData u
	on a.