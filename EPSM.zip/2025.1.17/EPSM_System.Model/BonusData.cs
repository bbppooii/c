﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EPSM_System.Model
{
    public class BonusData
    {
        public int ID { get; set; }
        public int Bonus { get; set; }
        public int Fine { get; set; }
        public int BonusInTotal { get; set; }
        public string Name { get; set; }
    }
}
