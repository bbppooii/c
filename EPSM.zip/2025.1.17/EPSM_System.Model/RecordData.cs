﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EPSM_System.Model
{
    public class RecordData
    {
        public int ID { get; set; }
        public String Name { get; set; }
        public String Position { get; set; }
        public String Age { get; set; }
        public String Sex { get; set; }
    }
}
